from potrace._potrace import *  # NOQA


__version__ = "0.2"
